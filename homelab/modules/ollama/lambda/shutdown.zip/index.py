import boto3
import os
def handler(event, context):
    ec2 = boto3.client('ec2', region_name=os.environ['AWS_REGION'])
    instance_id = os.environ['INSTANCE_ID']
    state = ec2.describe_instances(InstanceIds=[instance_id])['Reservations'][0]['Instances'][0]['State']['Name']
    if state == 'running':
        ec2.stop_instances(InstanceIds=[instance_id])
        return f"Stopped {instance_id}"
    return f"Instance {instance_id} already {state}"
